"""
Placeholder for DataService methods.
"""

from cm.services import Service

class DataService( Service ):
    
    def __init__(self, app):
        super(DataService, self).__init__(app)
