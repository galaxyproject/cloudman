"""The CloudMan Application."""

from cm.framework import expose, url_for
