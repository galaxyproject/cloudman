# -*- encoding:ascii -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 5
_modified_time = 1279295164.6731119
_template_filename='templates/instance_feed.mako'
_template_uri='instance_feed.mako'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding='ascii'
_exports = []


def render_body(context,**pageargs):
    context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        instances = context.get('instances', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1

        if instances is not None:
                context.write(" : ".join([" | ".join([str(y) for y in x.get_status_array()]) for x in instances]))
                 # compresses list of instances to be a string separated by : with instance fields separated by |
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['y','x'] if __M_key in __M_locals_builtin_stored]))
        return ''
    finally:
        context.caller_stack._pop_frame()


